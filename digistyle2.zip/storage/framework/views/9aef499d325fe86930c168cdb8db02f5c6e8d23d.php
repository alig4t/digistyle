<?php $__env->startSection('meta'); ?>
<title>مدیریت فروشگاه | 
افزودن موجودی
<?php echo e($product->title); ?>

</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .colorhex {
    display: block;
    width: 100px;
    height: 10px;
    margin: auto;
    border: 1px solid #ddd;
        color:#fff;
}
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

 <div class="content-header">
      <div class="container-fluid">
        <div class="row">
            <div class="col-12 mb-2 mt-2">
                <?php if(Session::has('add_stock')): ?>
                <div class="alert alert-success">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('add_stock')); ?></h6>
                </div>   
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">مدیریت انبار</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">خانه</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('products.index')); ?>">محصولات</a></li>
              <li class="breadcrumb-item active">موجودی محصول <?php echo e($product->title); ?></li>

            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>




 <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
          <div class="col-10 mx-auto">
            <?php if(count($errors)>0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6><i class="icon fa fa-ban"></i> <?php echo e($err); ?></h6>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
            

            <div class="col-md-10 mx-auto">
                <!-- general form elements -->
                <div class="card card-warning ">
                  <div class="card-header">
                    <h3 class="card-title">
                     افزودن موجودی محصول
                    </h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form role="form" method="POST" action="<?php echo e(route('stock.store')); ?>">
                    
                    <div class="card-body" id="card-box">
                        <?php echo csrf_field(); ?>
                      <div class="form-group">
                          
                        
                      <label>محصول</label>
                        <input disabled type="text" value="<?php echo e($product->title); ?>" class="form-control" placeholder="وارد کردن مقدار ...">
                      </div>


                      <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                       

                      <div class="row">
                    <div class="col-sm-4">
                      
                        <div class="form-group">
                            <label>انتخاب سایز</label>
                            <select class="form-control" name="size_id">
                                <option value="null">یک سایز انتخاب نمایید</option>
                                
                                <?php $__currentLoopData = \App\Size::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($size->id); ?>"><?php echo e($size->size); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                           </div>
                    
                    </div>
                       
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label>انتخاب رنگ</label>
                            <select class="form-control" name="color_id">
                                <option value="null">یک رنگ انتخاب نمایید</option>
                                
                                <?php $__currentLoopData = \App\Color::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($color->id); ?>"><?php echo e($color->color); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                           </div>
                    </div>

                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label>تعداد</label>
                           <input type="number" name="count" min="0" class="form-control" placeholder="تعداد را به عدد وارد نمایید..">
                           </div>
                    </div>
                      </div>
                       


                       

                       
                            
                    </div>
                    <div class="card-body">
                        <button type="button" onclick="insertInput()" id="add-button" class="btn btn-info btn-flat">اضافه کردن مقادیر بیشتر</button>
                    </div>
                    <div class="card-footer mt-2">
                      <button type="submit" class="btn btn-primary pull-left">افزودن موجودی</button>
                    </div>
                    
                  
                </div></form>
                <!-- /.card -->
    
                <!-- Form Element sizes -->
              
    
              </div>
              <!--/.col (left) -->
            
              <!--/.col (right) -->
            </div>






          <!-- /.row -->
        </div>





        <div class="row">
        
            <div class="col-12 mb-2 mt-2">
                <?php if(Session::has('update_stock')): ?>
                <div class="alert alert-success">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('update_stock')); ?></h6>
                </div>   
                <?php endif; ?>
            </div>
       




            <div class="col-lg-12">
              
              <div class="card p-2">
                
                <div class="card-header align-middle text-center">
                  <h3 class="card-title pull-right">
                    موجودی محصول
                  <?php echo e($product->title); ?>

                 </h3>
                 <span class="pull-left">
                    تعداد کل : <?php echo e($totalCount); ?> عدد
                 </span>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                  <table class="table table-bordered">
                    <tbody>
                        
                      <tr>
                        <th class="align-middle text-center">کدکالا:<?php echo e($product->sku); ?></th>
                      <th class="align-middle text-center">رنگ</th>
                      <th class="align-middle text-center">سایز</th>
                      <th class="align-middle text-center">تعداد</th>
                      <th class="align-middle text-center"> عملیات</th>

                    </tr>
                    <td rowspan="14" class="align-middle text-center">
                        <img src="/images/products/<?php echo e($product->photos[0]->path); ?>" width="150px" class="d-inline">

                    </td>
  
                      <?php $__currentLoopData = $product->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr class="">
                        

                      <td class="align-middle text-center font-weight-bold">
                        <?php echo e($stock->color->color); ?>

                        <span class="colorhex" style="background-color:<?php echo e($stock->color->hex); ?>">
                            
                        </span>
                    </td>
                    <td class="align-middle text-center font-weight-bold">
                        <?php echo e($stock->size->size); ?>

                    </td>
                    <td class="align-middle text-center font-weight-bold">
                        <?php echo e($stock->count); ?>

                        عدد
                    </td>
                      

                      <td class="align-middle text-center">

                            <form class="form-inline justify-content-center" action="<?php echo e(route('stock.update',$stock->id)); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="_method" value="PATCH">
                              <input type="hidden" name="stock_id" value="<?php echo e($stock->id); ?>">

                              <div class="form-group mb-2">
                                  <input type="number" name="count" min="0" value="<?php echo e($stock->count); ?>" class="form-control ml-2" placeholder="تعداد را به عدد وارد نمایید..">
                                  <input type="submit" class="btn btn-info btn-sm" value="ثبت موجودی">
                              </div>
                            </form>
                        </div>   
                      </td>
  
  
  
                      </tr>
  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                  
                      
  
  
  
  
  
  
  
                  </tbody></table>
                </div>
                <!-- /.card-body -->
              </div>
  
            </div>
            
          </div>
          


        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>














<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    var inputIndex = 1;
    var cardbox = document.getElementById('card-box');

    function  insertInput(){
       inputIndex += 1;
       let divtag = document.createElement('div');
       divtag.className = 'form-group';
        
       let newLabel = document.createElement('label');
       newLabel.textContent = 'وارد کردن مقدار ویژگی ' + inputIndex +' (اختیاری) '
       divtag.prepend(newLabel);

       let forminput = document.createElement('input');
       forminput.setAttribute('type','text');
       forminput.setAttribute('name','title[]');
       forminput.setAttribute('placeholder','وارد کردن مقدار ...');
       forminput.className = 'form-control';
        divtag.append(forminput);

        
        cardbox.append(divtag)


    }


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>