<?php $__env->startComponent('mail::message'); ?>
#ورود مدیریت به پنل

<h2>
<?php echo e($user->name); ?>


 به پنل مدیریت خوش آمدید  
</h2>
<h3>
 شما در تاریخ و ساعت <?php echo e($time); ?>

وارد پنل کاربری خود شده اید
</h3>
<?php echo $__env->renderComponent(); ?>