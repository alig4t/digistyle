<?php $__env->startSection('meta'); ?>
<title>مدیریت فروشگاه | 
   محصولات
</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

 <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">مدیریت محصولات</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">خانه</a></li>
              <li class="breadcrumb-item active">محصولات</li>
            </ol>
          </div><!-- /.col -->
          
          <div class="col-12 mt-4">
            <?php if(Session::has('add_product')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('add_product')); ?></h6>
            </div>   
            <?php endif; ?>

            <?php if(Session::has('edit_product')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('edit_product')); ?></h6>
            </div>   
            <?php endif; ?>

            <?php if(Session::has('delete_product')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('delete_product')); ?></h6>
            </div>   
            <?php endif; ?>
          </div>

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>




 <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          
          <div class="col-lg-12">
            
            <div class="card p-2">
              
              <div class="card-header align-middle text-center">
                <h3 class="card-title pull-right">لیست محصولات</h3>
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-app pull-left">
                  <i class="fa fa-plus"></i> جدید
                </a>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                    <th class="align-middle text-center">کدکالا</th>
                    <th class="align-middle text-center" width="150px">نام و آدرس سئو</th>
                    <th class="align-middle text-center">تصویر</th>
                    <th class="align-middle text-center">دسته بندی</th>
                    <th class="align-middle text-center" width="200px">ویژگی ها</th>
                    
                    <th class="align-middle text-center" width="200px">موجودی</th>

                    <th class="align-middle text-center">عملیات</th>

                  </tr>
                  

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                    <td class="align-middle text-center"><?php echo e($product->sku); ?></td>
                    <td class="align-middle text-center font-weight-bold"><a href="<?php echo e(route('product.show',$product->slug)); ?>"><?php echo e($product->title); ?></a></td>
                    <td class="align-middle text-center">
                      
                        <img src="/images/products/<?php echo e($product->photos[0]->path); ?>" width="150px" class="d-inline">
                      
                    </td>
                    <td class="align-middle text-center"><?php echo e($product->category->title); ?></td>
                    <td class="align-middle text-center">   
                      <ul class="list-group ul-attr-index">





                          <?php ($array_gp = []); ?>

                          <?php $__currentLoopData = $product->AttributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php ($gp = $att_val->attr_groups->title); ?>
                          <?php ($val = $att_val->title); ?>

                          <?php if(array_key_exists($gp , $array_gp)): ?>
                            <?php (array_push($array_gp[$gp], $val)); ?>
                          <?php else: ?>
                          <?php ($array_gp[$gp] = [$val]); ?>          
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <?php $__currentLoopData = $array_gp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <li class="list-group-item">
                            <?php echo e($key); ?>

                            :
                            <?php ($val = implode(" - ",$val)); ?>
                            <?php echo e($val); ?>

                          </li>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>



                    


                    <td class="align-middle text-center">
                      <?php ($tedad = 0); ?>
                      <?php if(count($product->stocks)>0): ?>
                      <ul class="list-group ul-attr-index">
                      <?php $__currentLoopData = $product->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="list-group-item">
                      
                      <?php ($tedad += $stock->count); ?>
                      <span class="d-block">
                        سایز: 
                     <?php echo e($stock->size->size); ?>

                      </span>
                      <span class="d-block">
                        رنگ: 
                        <?php echo e($stock->color->color); ?>

                      </span>

                        <span class="d-block" style="color:red">
                          تعداد: 
                          <?php echo e($stock->count); ?>

                          عدد
                        </span>
                     

                      </li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <li class="list-group-item" style="padding: 0 !important">
                        <span class="d-block font-weight" style="background-color:rgb(104, 221, 145);padding: 7px 2px;">
                          مجموع کل:
                          <?php echo e($tedad); ?>

                          عدد
                        </span>
                       
                      </li>
                      </ul>
                      <?php endif; ?>
                    
                    </td>


                    <td class="align-middle text-center">
                      <a href="<?php echo e(route('stock.add',$product->id)); ?>" class="btn btn-warning btn-sm mb-4">افزودن موجودی</a>
                      <div class="btn-group">

                        <a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-info btn-sm">ویرایش</a>    
                        <form class="d-inline" action="<?php echo e(route('products.destroy',$product->id)); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="_method" value="DELETE">
                          <input type="submit" class="btn btn-danger btn-sm" value="حذف">
                        </form>
                      </div>   
                    </td>



                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                
                    







                </tbody></table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>
          
        </div>
        <!-- /.row -->
        <!-- Main row -->
       
        
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>

















<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>