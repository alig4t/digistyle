<?php $__env->startSection('meta'); ?>
<title>مدیریت فروشگاه | 
    دسته بندی ها
</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

 <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">مدیریت دسته بندی ها</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">خانه</a></li>
              <li class="breadcrumb-item active">دسته بندی ها</li>
            </ol>
          </div><!-- /.col -->
          
          <div class="col-12 mt-4">
            <?php if(Session::has('new_cat')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('new_cat')); ?></h6>
            </div>   
            <?php endif; ?>

            <?php if(Session::has('edit_cat')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('edit_cat')); ?></h6>
            </div>   
            <?php endif; ?>

            <?php if(Session::has('delete_cat')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6 style="margin: 0"><i class="icon fa"></i> <?php echo e(Session('delete_cat')); ?></h6>
            </div>   
            <?php endif; ?>
          </div>

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>




 <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          
          <div class="col-12">
            
            <div class="card">
              
              <div class="card-header align-middle text-center">
                <h3 class="card-title pull-right">لیست دسته بندی ها</h3>
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-app pull-left">
                  <i class="fa fa-plus"></i> جدید
                </a>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <table class="table table-bordered">
                  <tbody><tr>
                    <th style="width: 10px">#</th>
                    <th class="align-middle text-center">نام</th>
                    <th class="align-middle text-center">آدرس سئو</th>
                    <th class="align-middle text-center">والد</th>
                    <th class="align-middle text-center">تصویر</th>
                    <th class="align-middle text-center">ویژگی ها</th>
                    <th class="align-middle text-center">عملیات</th>

                  </tr>
                  

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-gray">
                    <td class="align-middle text-center"><?php echo e($category->id); ?></td>
                    <td class="align-middle text-center font-weight-bold"><a href="<?php echo e(route('categories.edit',$category->id)); ?>"><?php echo e($category->title); ?></a></td>
                    <td class="align-middle text-center"><?php echo e($category->slug); ?></td>
                    <td class="align-middle text-center">دسته والد</td>
                    <td class="align-middle text-center"><img src="/images/cats/<?php echo e($category->photo); ?>" width="200px"></td>
                   
                    <td class="align-middle text-center">
                      <ul class="list-group ul-attr-index">
                      <?php $__currentLoopData = $category->attributegroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <li class="list-group-item"><?php echo e($attr->title); ?></li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </td>
                   
                   
                    <td class="align-middle text-center">
                      <div class="btn-group">
                      <a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-info btn-sm">ویرایش</a>
                      <?php if(count($category->childrenRecursive)>0): ?>
                      <button type="button" class="btn btn-gray btn-sm disabled font11">غیر قابل حذف</button>
                      </div>
                      <?php else: ?>
                      <form class="d-inline" action="<?php echo e(route('categories.destroy',$category->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="submit" class="btn btn-danger btn-sm" value="حذف">
                      </form>
                    </div>
                      <?php endif; ?>
                    </td>

                    
                   







                    </tr>

                    <?php if($category->childrenRecursive): ?>
                 
                      <?php echo $__env->make('backend.categories.catlist-partial',['catchild'=>$category,'level'=>1,'list'=>'list'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
                      <?php endif; ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                </tbody></table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>
          
        </div>
        <!-- /.row -->
        <!-- Main row -->
       
        
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>





















<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      
        <div class="col-12">
          
          




        </div>    <!-- /.col12 -->
      
    </div> <!--row -->
</section>








<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>