<?php $__env->startSection('meta'); ?>
<title>مدیریت فروشگاه | 
   ایجاد دسته بندی
</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="/dist/css/dropzone.min.css">

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

 <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">مدیریت دسته بندی ها</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">خانه</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('categories.index')); ?>">دسته بندی ها</a></li>
              <li class="breadcrumb-item active">ایجاد دسته بندی جدید</li>

            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>




 <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
          <div class="col-10 mx-auto">
            <?php if(count($errors)>0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6><i class="icon fa fa-ban"></i> <?php echo e($err); ?></h6>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
            

            <div class="col-md-10 mx-auto">
                <!-- general form elements -->
                <div class="card card-warning ">
                  <div class="card-header">
                    <h3 class="card-title">
                      ایجاد دسته بندی جدید
                    </h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form role="form" method="POST" action="<?php echo e(route('categories.store')); ?>" enctype="multipart/form-data">
                    
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                      <div class="form-group">
                        
                        <label>عنوان</label>
                        <input type="text" name="title" class="form-control" placeholder="وارد کردن عنوان ...">
                      </div>
  
                      <div class="form-group">
                        <label>آدرس URL</label>
                        <input type="text" name="slug" class="form-control" placeholder="url را وارد نمایید...">
                      </div>
  
                    
                        <div class="form-group">
                          <label>دسته والد</label>
                          <select class="form-control" name="parent">
                            <option value="0">بدون والد</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                           
                            <?php if(count($category->childrenRecursive)>0): ?>
                            <?php echo $__env->make('backend.categories.catlist-partial',['catchild'=>$category,'level'=>1,'create'=>'create'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                        
                            <?php endif; ?>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                       

                        <div class="form-group">
                          <label>متای توضیحات</label>
                          <textarea rows="3" name="meta_desc" class="form-control" placeholder="توضیحات موضوع جهت نمایش در گوگل..."></textarea>
                        </div>
  

                        
                        <div class="form-group mt-4 mb-4">
                          <label class="d-block">ویژگی های این کتگوری را انتخاب نمایید</label>
                          


                          <?php $__currentLoopData = $attr_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr_gp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-check d-inline">
                              <input class="form-check-input" type="checkbox" name="attr-gps[]" value="<?php echo e($attr_gp->id); ?>">
                              <label class="form-check-label ml-3"><?php echo e($attr_gp->title); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>




                        






                        <div class="form-group d-block">
                          <label class="d-block" for="exampleFormControlFile1">تصویر شاخص</label>
                          <div class="input-group">
                          <input type="file" name="image" class="form-control-file" id="exampleFormControlFile1">
                          </div>
                        </div>
  
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">ایجاد دسته بندی</button>
                    </div>
                    
                  
                </div></form>
                <!-- /.card -->
    
                <!-- Form Element sizes -->
              
    
              </div>
              <!--/.col (left) -->
            
              <!--/.col (right) -->
            </div>






          <!-- /.row -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>














<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>