<?php if(isset($list)): ?>

<?php $__currentLoopData = $catchild->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="sub-cat-tr">
              <td class="align-middle text-center"><?php echo e($children->id); ?></td>

             <td class="align-middle text-center"><?php echo e(str_repeat("---",$level)); ?><a href="<?php echo e(route('categories.edit',$children->id)); ?>"><?php echo e($children->title); ?></a></td>
             <td class="align-middle text-center"><?php echo e($children->slug); ?></td>
                <td class="align-middle text-center"><?php echo e($children->parent->title); ?></td>
                <td class="align-middle text-center"><img src="/images/cats/<?php echo e($children->photo); ?>" width="200px"></td>

                <td class="align-middle text-center">
                  <ul class="list-group ul-attr-index">
                  <?php $__currentLoopData = $children->attributegroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <li class="list-group-item"><?php echo e($attr->title); ?></li>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </td>
          
             <td class="align-middle text-center">
              <div class="btn-group">
               <a href="<?php echo e(route('categories.edit',$children->id)); ?>" class="btn btn-info btn-sm">ویرایش</a>
               <?php if(count($children->childrenRecursive)>0): ?>
           
               <button type="button" class="btn btn-gray btn-sm font11 disabled">غیر قابل حذف</button>
              </div>
               <?php else: ?>
               <form class="d-inline" action="<?php echo e(route('categories.destroy',$children->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" value="DELETE">
                <input type="submit" class="btn btn-danger btn-sm" value="حذف">
              </form>  
            </div>           
                <?php endif; ?>
             </td>

            







             <?php if($children->childrenRecursive): ?>
               <?php echo $__env->make('backend.categories.catlist-partial',['catchild'=>$children,'level'=>$level+2,'list'=>'list'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
             <?php endif; ?>

            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endif; ?>



<?php if(isset($edit)): ?>






<?php $__currentLoopData = $catchild->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($show == 'disabled'): ?>

<?php else: ?>
          <?php if($children->id == $cat->id): ?>
              <?php ($show='disabled'); ?>
            <?php else: ?>
              <?php ($show=''); ?>
            <?php endif; ?>

<?php endif; ?>
            
<option value="<?php echo e($children->id); ?>" <?php if($cat->parent_id == $children->id): ?> selected <?php endif; ?> <?php echo e($show); ?>><?php echo e(str_repeat("---",$level)); ?> <?php echo e($children->title); ?></option>
            
            
             <?php if(count($children->childrenRecursive)>0): ?>
               <?php echo $__env->make('backend.categories.catlist-partial',['catchild'=>$children,'show'=>$show,'level'=>$level+2,'edit'=>'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
             <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<?php endif; ?>


<?php if(isset($create)): ?>




<?php $__currentLoopData = $catchild->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <option value="<?php echo e($children->id); ?>"><?php echo e(str_repeat("---",$level)); ?> <?php echo e($children->title); ?></option>

             <?php if(count($children->childrenRecursive)>0): ?>
               <?php echo $__env->make('backend.categories.catlist-partial',['catchild'=>$children,'level'=>$level+2,'create'=>'create'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
             <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php endif; ?>






<?php if(isset($pr_edit)): ?>


<?php $__currentLoopData = $catchild->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            
<option value="<?php echo e($children->id); ?>" <?php if($product->category->id == $children->id): ?> selected <?php endif; ?>><?php echo e(str_repeat("---",$level)); ?> <?php echo e($children->title); ?></option>
            
             <?php if(count($children->childrenRecursive)>0): ?>
               <?php echo $__env->make('backend.categories.catlist-partial',['catchild'=>$children,'level'=>$level+2,'pr_edit'=>'pr_edit'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
             <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endif; ?>

