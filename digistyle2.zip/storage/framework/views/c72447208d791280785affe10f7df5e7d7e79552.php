<?php $__env->startSection('styles'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style>
      .mb-0{
        margin-bottom: 2px;
      }
      .mb-4{
        margin-bottom: 7px;
      }
      .d-inline{
        float: right;
      }
      .d-block{
        display: block;
      }
      .font-weight-bold{
        font-weight: bold;
      }
      .ml-4{
        margin-left: 8px;
      }
      .ml-2{
        margin-left: 14px;
      }
      .inline-block{
        display: inline-block;
      }
    </style>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>


<div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-home"></i></a></li>
        <li><a href="category.html">الکترونیکی</a></li>
      </ul>
      <!-- Breadcrumb End-->
      <div class="row">
        <!--Left Part Start -->
        <aside id="column-left" class="col-sm-3 hidden-xs">
          












          <h3 class="subtitle d-block">دسته ها</h3>
          <div class="box-category">
            <ul id="cat_accordion">
              <li><a href="category.html">مد و زیبایی</a> <span class="down"></span>
                <ul>
                  <li><a href="category.html">آقایان</a> <span class="down"></span>
                    <ul>
                      <li><a href="category.html">زیردسته ها</a></li>
                      <li><a href="category.html">زیردسته ها</a></li>
                      <li><a href="category.html">زیردسته ها</a></li>
                      <li><a href="category.html">زیردسته ها</a></li>
                      <li><a href="category.html">زیردسته جدید</a></li>
                    </ul>
                  </li>
                  <li><a href="category.html">بانوان</a></li>
                  <li><a href="category.html">دخترانه</a> <span class="down"></span>
                    <ul>
                      <li><a href="category.html">زیردسته ها</a></li>
                      <li><a href="category.html">زیردسته جدید</a></li>
                      <li><a href="category.html">زیردسته جدید</a></li>
                    </ul>
                  </li>
                  <li><a href="category.html">پسرانه</a></li>
                  <li><a href="category.html">نوزاد</a></li>
                  <li><a href="category.html">لوازم</a> <span class="down"></span>
                    <ul>
                      <li><a href="category.html">زیردسته های جدید</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              
              
              <li><a href="category.html">زیبایی و سلامت</a> <span class="down"></span>
                <ul>
                  <li><a href="category.html">عطر و ادکلن</a></li>
                  <li><a href="category.html">آرایشی</a></li>
                  <li><a href="category.html">ضد آفتاب</a></li>
                  <li><a href="category.html">مراقبت از پوست</a></li>
                  <li><a href="category.html">مراقبت از چشم</a></li>
                  <li><a href="category.html">مراقبت از مو</a></li>
                </ul>
              </li>
            </ul>
          </div>
          <h3 class="subtitle">پرفروش ها</h3>
          <div class="side-item">
            <div class="product-thumb clearfix">
              
              <div class="caption">
                <h4><a href="product.html">تی شرت کتان مردانه</a></h4>
                <p class="price"><span class="price-new">110000 تومان</span> <span class="price-old">122000 تومان</span> <span class="saving">-10%</span></p>
              </div>
            </div>
           


          </div>
          <h3 class="subtitle">ویژه</h3>
          <div class="side-item">
            <div class="product-thumb clearfix">
              
              <div class="caption">
                <h4><a href="product.html">کتاب آموزش باغبانی</a></h4>
                <p class="price"> <span class="price-new">98000 تومان</span> <span class="price-old">120000 تومان</span> <span class="saving">-26%</span> </p>
              </div>
            </div>

          
          </div>
          <div class="banner owl-carousel">
            
            
          </div>
        </aside>
        <!--Left Part End -->
        <!--Middle Part Start-->
        <div id="content" class="col-sm-9">
          
          
          <h3 class="subtitle">
            جستجو برای 
          <?php echo $params['q']; ?>

          </h3>
          <div class="category-list row">
                        
                
                
                      </div>
          
                     

          <div class="product-filter">
            <div class="row">
              <div class="col-md-2 col-sm-3">
                <div class="btn-group">
                  <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
                  <button type="button" id="grid-view" class="btn btn-default" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
                </div>
                 </div>
              <div class="col-sm-1 text-right">
                <label class="control-label" for="input-sort">مرتب سازی:</label>
              </div>
              <div class="col-md-3 col-sm-3 text-right">
                <select id="input-sort" class="form-control col-sm-11" onchange="sortby(this)">
                  
                  <option value="newest" <?php if($params['sortby'] == 'newest'): ?> selected <?php endif; ?>>جدیدترین</option>
                  <option value="price-low-to-high" <?php if($params['sortby'] == 'price-low-to-high'): ?> selected <?php endif; ?>>قیمت (کم به زیاد)</option>
                  <option value="price-high-to-low" <?php if($params['sortby'] == 'price-high-to-low'): ?> selected <?php endif; ?> >قیمت (زیاد به کم)</option>
                </select>
              </div>


              <div class="col-sm-1 text-right">
                <label class="control-label" for="input-limit">نمایش:</label>
              </div>
              
              <div class="col-sm-2 text-right">
                <select id="input-limit" class="form-control" onchange="showMax(this)">
                  <option value="16" <?php if($params['show'] == 16): ?> selected <?php endif; ?>>16</option>
                  <option value="2" <?php if($params['show'] == 2): ?> selected <?php endif; ?>>2</option>
                  <option value="3" <?php if($params['show'] == 3): ?> selected <?php endif; ?>>3</option>
                  <option value="24" <?php if($params['show'] == 24): ?> selected <?php endif; ?>>24</option>
                </select>

              </div>
            </div>
          </div>
          <br />
          <div class="row products-category">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="product-layout product-list col-xs-12">
                <div class="product-thumb">
                  <div class="image"><a href="<?php echo e($product->path()); ?>"><img width="220px" src="/images/products/<?php echo e($product->photos[0]->path); ?>" alt=" کتاب آموزش باغبانی " title=" کتاب آموزش باغبانی " class="img-responsive" /></a></div>
                  <div>
                    <div class="caption">
                      <h4><a href="<?php echo e($product->path()); ?>"><?php echo e($product->title); ?></a></h4>
                      <p class="description"></p>
                      <?php if($product->discount > 0): ?>
                      <p class="price"><span class="price-new"><?php echo e($product->price - $product->discount); ?> تومان</span> <span class="price-old"><?php echo e($product->price); ?> تومان</span> <span class="saving"><?php echo e(floor(($product->discount)/$product->price * 100)); ?>%</span></p>     
                      <?php else: ?>
                      <p class="price"><span class="price-new"><?php echo e($product->price); ?> تومان</span> </p>     

                      <?php endif; ?>
                    </div>
                    <div class="button-group">
                      <button class="btn-primary" type="button" onClick=""><span>افزودن به سبد</span></button>
                      <div class="add-to-links">
                        <button type="button" data-toggle="tooltip" title="افزودن به علاقه مندی ها" onClick=""><i class="fa fa-heart"></i> <span>افزودن به علاقه مندی ها</span></button>
                        <button type="button" data-toggle="tooltip" title="مقایسه این محصول" onClick=""><i class="fa fa-exchange"></i> <span>مقایسه این محصول</span></button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>


          <div class="row">
            <div class="col-sm-6 text-left">
              <ul class="pagination">
                <?php echo e($products->appends(request()->query())->links()); ?>


              </ul>
            </div>
            <div class="col-sm-12 text-right">
              

              نمایش <?php echo e($products->firstItem()); ?> تا <?php echo e($products->lastItem()); ?> از <?php echo e(count($products)); ?> (مجموع <?php echo e($products->lastPage()); ?> صفحه)
              
            </div>
          </div>
        </div>
        <!--Middle Part End -->
      </div>
    </div>
  </div>


  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>



<script>

  var queries = {<?php $__currentLoopData = $params['attributes_array']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> '<?php echo e($key); ?>':[<?php echo e($row); ?>], <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>};
  console.log(queries);
  var q = "<?php echo e($params['q']); ?>";
  var sortBy = "<?php echo e($params['sortby']); ?>";
  var showPerPage = "<?php echo e($params['show']); ?>";
  var currentpage = "<?php echo e($params['page']); ?>";
  var current_url = "<?php echo e(request()->url()); ?>";

  console.log(q);
</script>  

 <script src="<?php echo e(asset('js/cat-filter.js')); ?>"></script> 



<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>