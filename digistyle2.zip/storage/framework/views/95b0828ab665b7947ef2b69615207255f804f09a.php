<?php $__env->startSection('meta'); ?>
<title>مدیریت فروشگاه | 
   تعریف سایز جدید
</title>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

 <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">مدیریت سایزها</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">خانه</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('sizes.index')); ?>">سایزها</a></li>
              <li class="breadcrumb-item active">تعریف سایز جدید</li>

            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>




 <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        
          

          <?php echo $__env->make('backend.layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            

            <div class="col-md-10 mx-auto">
                <!-- general form elements -->
                <div class="card card-warning ">
                  <div class="card-header">
                    <h3 class="card-title">
                      تعریف سایز جدید
                    </h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form role="form" method="POST" action="<?php echo e(route('sizes.store')); ?>" enctype="multipart/form-data">
                    
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label>اندازه</label>
                        
                        <label class="d-block">مثال : M - 36 - XXL</label>

                        <input type="text" name="size" class="form-control" value="<?php echo e(old('size')); ?>" placeholder="وارد کردن اندازه ...">
                      </div>
  
                      <div class="form-group">
                        <label>توضیح کوتاه سایز (اختیاری)</label>
                        <input type="text" name="description" class="form-control" value="<?php echo e(old('description')); ?>" placeholder="وارد کردن توضیح (اختیاری)  ...">
                      </div>

  
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">ایجاد سایز</button>
                    </div>
                    
                  
                </div></form>
                <!-- /.card -->
    
                <!-- Form Element sizes -->
              
    
              </div>
              <!--/.col (left) -->
            
              <!--/.col (right) -->
            </div>






          <!-- /.row -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>














<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>