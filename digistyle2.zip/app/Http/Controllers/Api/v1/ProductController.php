<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{

    public function products_list(){

        $products = Product::select('id','title','price','discount')->latest()->get();
        return response(['data'=>$products,'status'=>200],200);

    }
    
    public function add_comment(Request $request){

        $valid = Validator::make($request->all(),[
            'name' => 'required',
            'body' => 'required'
        ]);
        // dd($request->all());

        if($valid->fails()){
            return response(['data'=> $valid->errors()->all() , 'status'=>403],403);
        }

    }


}
